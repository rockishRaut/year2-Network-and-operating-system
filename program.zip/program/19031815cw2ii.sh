#!bin/bash

askSecretKey() {
	secretCode="123"
	counters=5
	while [[ $counters > 0 ]]; do
		echo "Enter your secret key"
		read -s secretKey

		if [[ $secretKey == $secretCode ]]; then
			welcome
			break

		else
			((counters--))
			echo "Please enter correct secret key, you have got only $counters health left"

		fi

	done
	if [[ $counters == 0 ]]; then
		echo "Sorry Your game is over because all of your health is depleted"
		exit
	fi
}
display() {
	echo "please guess any one of the football team that is best in the world"
	echo ""
	echo "-----------------------------------------------------------------------"
	echo "|     COUNTRIES                   |     COUNTRY CODE                  |"
	echo "|-------------------------------------------------------------------- |"
	echo "|      CHINA                      |          CHI                      |"
	echo "|      BRASIL                     |          BRZ                      |"
	echo "|      ENGLAND                    |          ENG                      |"
	echo "|      ARGENTINA                  |          ARG                      |"
	echo "|      NEPAL                      |          NEP                      |"
	echo "|_____________________________________________________________________|"
	echo ""
	echo -e "NOW ENTER THE COUNTRY CODE FOOTBALL TEAM WHICH DO YOU THINK IS THE BEST: "

	levelOne

}

levelOne() {
	x="ARG"

	read fav
	if [[ $fav == "BRZ" || $fav == "ARG" || $fav == "ENG" || $fav == "CHI" || $fav == "NEP" ]]; then
		if [[ $x == $fav ]]; then
			displayPlayers

		else
			echo "Sorry your guess is wrong, please Enter another country code:"
			levelOne

		fi
	else
		echo "Please enter correct country code."
		levelOne
	fi
}

displayPlayers() {

	echo "Players"
	levelTwo
}

levelTwo() {
	echo ""
	echo "************************************************************************"
	echo "Here are some of the greatest players who played football"
	echo ""
	echo "-----------------------------------------------------------------------"
	echo "|     PLAYERS                            |     PLAYER CODE            |"
	echo "|-------------------------------------------------------------------- |"
	echo "|      LIONEL MESSI                      |          LM                |"
	echo "|      NEYMAR JUNIOR                     |          NJ                |"
	echo "|      KIRAN CHEMJONG                    |          KC                |"
	echo "|      ZHENG ZHI                         |          ZZ                |"
	echo "|      HARRY KANE                        |          HK                |"
	echo "|_____________________________________________________________________|"
	echo ""
	echo "************************************************************************"

	gotAllPlayers=false
	echo -e "please guess any 3 of the Player who do you think is the best in the world:\c"
	read p1 p2 p3
	choosedPlayers=($p1 $p2 $p3)
	if [[ "${#choosedPlayers[@]}" == 3 ]]; then

		if [[ $p1 == $p2 || $p1 == $p3 || $p2 == $p3 ]]; then
		echo -e "Please select the three different players:\c"
			levelTwo
			

		else
			for cp in "${choosedPlayers[@]}"; do
				if [[ $cp == "LM" || $cp == "NJ" || $cp == "KC" || $cp == "HK" || $cp == "ZZ" ]]; then

					gotAllPlayers=true
				else
					echo -e "Please enter player which is in list:"
					gotAllPlayers=false
					levelTwo
					break
				fi
			done

			if [[ $gotAllPlayers == true ]]; then
				selectOnePlayer $p1 $p2 $p3
			fi
		fi

	else
		echo -e "You can only enter the code of any three players:"
		levelTwo
	fi
}

selectOnePlayer () {
	player1=$1
	player2=$2
	player3=$3

	PS3="Please select a player of which you want to know about: "
	select favPlayer in $player1 $player2 $player3
	do 
	echo ""
	if [ -z $favPlayer ]
	then
	echo "Please re select a player using number: "
	else 
	case $favPlayer in
	"LM") 
		cat LM
		doWantToContinue
		;;
		"NJ")
		cat NJ
		doWantToContinue;;
		"KC")
		cat KC
		doWantToContinue;;
		
		*)
		echo "We dont have player profile"
		display
		
		;;
	esac
	fi
	done
}

doWantToContinue (){
	correctInput=false
	echo "Do you want to continue? Type y to continue and n to exit"
	until [[ $correctInput == true ]]
	do
	
	read cont
	if [[ $cont == "y" ]]
	then
	correctInput=true
	elif [[ $cont == "n" ]]
	then
	correctInput=true
	echo "Exiting the program"
	exit
	else
	echo "Please only type y or n to continue or exit"
	correctInput=false
	fi
done
display
	
}

welcome() {
	echo ""
	echo "------------------------------------------------------------------------------------------------ "
	echo "|                                                                                                 "
	echo "|                    **** YOUR GAME ID IS $id *****                                               "
	echo "|  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _ "
	echo ""
	echo "|                ~~~WELCOME TO THE GAME OF FOOTBALL $name ~~~                                     "
	echo "|  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _  _ "
	echo ""
	echo "|          **** YOUR ARE PLAYING THIS GAME ON ERA ON $(date) *****                                "
	echo ""
	echo "|------------------------------------------------------------------------------------------------ "
	display
}

name=""
id=""

if [[ $# = 2 ]]; then

	name=$1
	id=$2
	askSecretKey
else
	echo ""
	echo "Please enter username and id to login"

fi
